/*!
* Start Bootstrap - Freelancer v7.0.4 (https://startbootstrap.com/theme/freelancer)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // barraNavegación shrink function
    var barranavShrink = function () {
        const barranavCollapsible = document.body.querySelector('#navegadorPrincipal');
        if (!barranavCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            barranavCollapsible.classList.remove('barranav-shrink')
        } else {
            barranavCollapsible.classList.add('barranav-shrink')
        }

    };

    // Shrink the barranav 
    barranavShrink();

    // Shrink the barranav when page is scrolled
    document.addEventListener('scroll', barranavShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const navegadorPrincipal = document.body.querySelector('#navegadorPrincipal');
    if (navegadorPrincipal) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#navegadorPrincipal',
            offset: 72,
        });
    };

    // Collapse responsive barranav when toggler is visible
    const barranavToggler = document.body.querySelector('.barranav-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#barranavResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(barranavToggler).display !== 'none') {
                barranavToggler.click();
            }
        });
    });

});
