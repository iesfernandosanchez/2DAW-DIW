*** English ***
Please, before making your own translation contact us.
Your help is great for us, but the worst case is when two people translate the same file at the same time (even if we take best of both files).
So please contact us before you start, this could avoid you losing time helping us.

Identifiers are not country-based but language-based, meaning that even if Japan code is JP (internet domains are .jp for instance), the good value to choose is JA, as the browser send JA as HTTP_ACCEPT_LANGUAGE (see http://www.webmasterworld.com/forum24/320.htm)


*** Français ***
Avant de vous lancer dans une traduction merci de nous prévenir.
Votre aide est précieuse pour nous, mais le pire cas qui peut arriver est que deux personnes traduisent ensemble le même fichier (même si on prend le meilleur de chaque).
Donc merci de nous prévenir avant de commencer, cela pourra vous éviter de perdre du temps en voulant nous aider.

Les identifiants ne sont pas par pays mais par langue, ce qui veut dire que même si le code du Japon est JP (domaines internet en .jp par exemple), la bonne valeur à sélectionner est JA, puisque le navigateur envoie JA comme HTTP_ACCEPT_LANGUAGE (voir http://www.webmasterworld.com/forum24/320.htm)